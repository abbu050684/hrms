# Copyright (c) 2019, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
import unittest


class TestAppointmentLetterTemplate(unittest.TestCase):
	pass
