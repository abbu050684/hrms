def get_data():
	return {
		"fieldname": "training_event",
		"transactions": [
			{"items": ["Training Result", "Training Feedback"]},
		],
	}
