def get_data():
	return {
		"fieldname": "job_title",
		"transactions": [{"items": ["Job Applicant"]}],
	}
