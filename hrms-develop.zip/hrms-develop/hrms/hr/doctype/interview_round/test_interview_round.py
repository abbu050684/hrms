# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

import unittest

# import frappe


class TestInterviewRound(unittest.TestCase):
	pass
